import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductTest {
    @Test
    public void testElectronicsCreationAndValue() {
        Electronics e = new Electronics(1, "TV", 5000, 2, 24);
        assertEquals(1, e.getId());
        assertEquals("TV", e.getName());
        assertEquals(5000, e.getPrice());
        assertEquals(2, e.getQuantity());
        assertEquals(24, e.getWarrantyMonths());
        assertEquals(10000, e.calculateValue());
    }

    @Test
    public void testClothingCreationAndValue() {
        Clothing c = new Clothing(2, "Shirt", 200, 5, "M");
        assertEquals(2, c.getId());
        assertEquals("Shirt", c.getName());
        assertEquals(200, c.getPrice());
        assertEquals(5, c.getQuantity());
        assertEquals("M", c.getSize());
        assertEquals(1000, c.calculateValue());
    }
}