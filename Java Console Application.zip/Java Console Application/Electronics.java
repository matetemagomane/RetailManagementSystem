public class Electronics extends Product {
    private int warrantyMonths;

    public Electronics(int id, String name, double price, int quantity, int warrantyMonths) {
        super(id, name, price, quantity);
        this.warrantyMonths = warrantyMonths;
    }

    public int getWarrantyMonths() {
        return warrantyMonths;
    }

    public void setWarrantyMonths(int warrantyMonths) {
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public double calculateValue() {
        return getPrice() * getQuantity();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Warranty: %d months", warrantyMonths);
    }
}