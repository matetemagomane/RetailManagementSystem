import java.util.Scanner;

public class RetailManagementSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create an array of products (size 10 for demo)
        Product[] inventory = new Product[10];
        int productCount = 0;

        // Add some sample products
        inventory[productCount++] = new Electronics(1, "Laptop", 12000, 3, 24);
        inventory[productCount++] = new Electronics(2, "Smartphone", 8000, 5, 12);
        inventory[productCount++] = new Clothing(3, "T-Shirt", 200, 20, "M");
        inventory[productCount++] = new Clothing(4, "Jeans", 600, 10, "L");

        boolean running = true;

        while (running) {
            System.out.println("\n==== Retail Management Menu ====");
            System.out.println("1. View Inventory");
            System.out.println("2. Add Product");
            System.out.println("3. Generate Report");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    // View inventory
                    System.out.println("\n--- Inventory List ---");
                    for (int i = 0; i < productCount; i++) {
                        System.out.println(inventory[i]);
                    }
                    break;

                case 2:
                    // Add product
                    if (productCount >= inventory.length) {
                        System.out.println("Inventory is full! Cannot add more.");
                        break;
                    }
                    System.out.println("Add Product: (1 = Electronics, 2 = Clothing)");
                    int type = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();

                    System.out.print("Enter Quantity: ");
                    int quantity = sc.nextInt();
                    sc.nextLine();

                    if (type == 1) {
                        System.out.print("Enter Warranty (months): ");
                        int warranty = sc.nextInt();
                        inventory[productCount++] = new Electronics(id, name, price, quantity, warranty);
                    } else if (type == 2) {
                        System.out.print("Enter Size: ");
                        String size = sc.nextLine();
                        inventory[productCount++] = new Clothing(id, name, price, quantity, size);
                    } else {
                        System.out.println("Invalid product type!");
                    }
                    break;

                case 3:
                    // Generate report
                    double totalValue = 0;
                    int electronicsCount = 0, clothingCount = 0;

                    for (int i = 0; i < productCount; i++) {
                        totalValue += inventory[i].calculateValue();
                        if (inventory[i] instanceof Electronics) {
                            electronicsCount++;
                        } else if (inventory[i] instanceof Clothing) {
                            clothingCount++;
                        }
                    }

                    System.out.println("\n==== Store Report ====");
                    System.out.println("Total Products: " + productCount);
                    System.out.println("Electronics: " + electronicsCount);
                    System.out.println("Clothing: " + clothingCount);
                    System.out.println("Total Inventory Value: R" + totalValue);
                    System.out.println("=======================");
                    break;

                case 4:
                    running = false;
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }

        sc.close();
    }
}
